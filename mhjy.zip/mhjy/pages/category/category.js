var server = require('../../utils/server');
var WxParse = require('../../wxParse/wxParse.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    url:app.globalData.url,
    picture:'',
    cate_list:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    if (options.user_id) {
      wx.setStorageSync('app_send_user_id', options.user_id);
    }
    if (app.globalData.user_id == '') {
      wx.showToast({
        title: '还没有登录',
        duration: 3000,
        success: function () {
          setTimeout(function () {
            wx.redirectTo({
              url: '../wode/choice/choice',
            })
          }, 2000) //延迟时间
        }
      })
    }
    // this.loadCate();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.loadCate();
   
  

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
 //下拉刷新
  onPullDownRefresh:function()
  {
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
    this.loadCate();
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    // var that = this;
    // var user_id = that.data.user_id;
    // var scene = 1;

    return {
      title: '美好家园苹果部落',
      desc: '美好家园苹果部落',
      path: '/pages/category/category?user_id=' + app.globalData.user_id
    }
  },

  loadCate: function () {
    var that = this;
    server.getJSON("/Goods/category_first", function (res) {
      var picture = res.data.result.adv;
      var cate_list = res.data.result.cate_list;
    //   console.log(cate_list)
      that.setData({
        picture:picture,
        cate_list:cate_list
      });
    });
  },

  goodsCate: function (e) {
    var Id = e.currentTarget.dataset.cateId;
    wx.navigateTo({
      url: '../goods/list/list?objectId=' + Id,
    })
  },

  bindViewTap: function (e) {
    var jump_type = e.currentTarget.dataset.jumpType;
    var jump_url = e.currentTarget.dataset.jumpUrl;

    if (jump_type == 0) {
      wx.navigateTo({
        url: "../goods/ceshi/ceshi?objectId=" + jump_url,
      });
    } else if (jump_type == 1) {
      wx.navigateTo({
        url: "../goods/details/details?objectId=" + jump_url,
      });
    } else if (jump_type == 2) {
      wx.navigateTo({
        url: "../goods/list/list?objectId=" + jump_url,
      });
    } else {
      url: "../goods/activity_goods/activity_goods?objectId=" + jump_url
    }
  }
})
