var server = require('../../../utils/server');
var WxParse = require('../../../wxParse/wxParse.js');
var app = getApp();
Page({
 data: {
    goods: {},

    current: 0,
    tabStates: [true, false, false],
    tabClasss: ["text-select", "text-normal", "text-normal"],
    galleryHeight: getApp().screenWidth,
    tab: 0,
    goods_num: 1,
    textStates: ["view-btns-text-normal", "view-btns-text-select"],
    article: '<div>我是HTML代码</div>',
    item_id: '',
    shop_price: '',
    team_price: '',
    store_count: '',
    url: app.globalData.url,
    home_list:'',
    my_list:'',

  },


  onLoad: function (options) {
// console.log(wx.getStorageSync('wxtoken'))
    this.getGroups();
    this.myGroups();


    // this.collectGoodsInfo(goodsId);
  },
  tabClick: function (e) {
    var index = e.currentTarget.dataset.index
    var classs = ["text-normal", "text-normal", "text-normal"]
    classs[index] = "text-select"
    this.setData({ tabClasss: classs, tab: index })
  },

   getGroups: function () {
    var that = this

    // var unionId = app.globalData.unionid;
    server.getJSON('/Order/home_list/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      // console.log(res.data.list)
     
      if(res.data.status != -1){
        var home_list = res.data.list;
        that.setData({
          home_list: home_list
        });
      }else{
        wx.showToast({
        title: '请先登录!',
        icon:'none'
        })
        wx.navigateTo({
          url:'../../wode/choice/choice'
        })
      }
        
    });
  },

  showDetail:function(e){
    // console.log(e.currentTarget.dataset)
    var goodsId = e.currentTarget.dataset.goodsId;
    // var groupId = e.currentTarget.dataset.groupId;

     wx.navigateTo({
        url: "../open_regiment/open_regiment?goodsId=" + goodsId
      })
  },


  myGroups: function () {
    var that = this;
    server.getJSON('/Order/home_list/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      // console.log(res)
      if(res.data.status != -1){

      var my_list = res.data.order;
      // console.log(my_list)

      that.setData({
        my_list: my_list
      });
    }else{
       wx.showToast({
        title: '请先登录!',
        icon:'none'
      })
      wx.navigateTo({
        url:'../../wode/choice/choice'
      })

    }
    });
  },
   myDetail:function(e){
    // console.log(e.currentTarget.dataset)
    var goodsId = e.currentTarget.dataset.goodsId;
    var groupId = e.currentTarget.dataset.groupId;


     wx.navigateTo({
        url: "../collage_detail/collage_detail?id=" + goodsId+ '&group_id=' + groupId,
      })
  },

  // onShareAppMessage: function () {
  //   return {
  //     title: '物华兴邦',
  //     desc: '物华兴邦',
  //     path: '/pages/index/index'
  //   }
  // }

});

