var server = require('../../../utils/server');
var WxParse = require('../../../wxParse/wxParse.js');
var app = getApp();
Page({

  data: {
    clock: '',
    img:'',
    goods_content:'',
    goods_name:'',
    id:0,
    goods_remark:'',
    team_price:0,
    shop_price:0,
    goods_id:0,
    shareimg:'',
    shareurl:'',
    group_id:0,
    is_crate:1,
    // 图片路径

    movies: [
      { url: '../../../img/ceshi.jpg' },
      { url: '../../../img/ceshi.jpg' },
      { url: '../../../img/ceshi.jpg' },
      { url: '../../../img/ceshi.jpg' },
    ],
    goods_id:0,
  },
  onLoad: function (options) {
    // console.log(options)
    var id = options.goodsId;
    this.setData({
      id: id
    })
     var that = this;
    server.getJSON('/LoginApi/group_goods/id/' + id, function (res) {
      // console.log(res)

      var group_goods = res.data.list;
      // console.log(group_goods)
      var goods_content = res.data.list.goods_content;
      that.setData({
        group_goods: group_goods,
        goods_id: group_goods.goods_id,
        goods_content:goods_content,
        // id : id, 

      });
      // console.log(group_goods)
        WxParse.wxParse('article', 'html', that.data.goods_content, that, 5);

    });
    

  },

  onShow: function () {
    this.goodsInfo();
  },
  goodsInfo:function(){
    var id = this.data.id;
    var that = this;
    // console.log(that.data)
     server.getJSON('/LoginApi/group_goods/id/' + id,function(res){
      console.log(res.data.team);
      if(res.data.team != ''){
        that.setData({
          team:res.data.team

        });

      }

    })

  },
  // 原价购买
  buyNow:function(){

    var goods_id = this.data.goods_id;
    // console.log(goods_id)
    wx.navigateTo({
      url:"../../goods/details/details?objectId=" + goods_id,
    })
    
  },
  // 开团
  group:function(){
    var group_id=0;
    var id = this.data.id;
    var is_crate = 1;
    var wxtoken = wx.getStorageSync('wxtoken');
     server.getJSON('/Order/checkauth/wxtoken/' + wxtoken + '/id/' + id,function(res){
      // console.log(res.data);
      if(res.data.status == 0){
        wx.showToast({
          title:res.data.msg,
          icon:'none'
        })
      }else{
        wx.navigateTo({
          url:"../queren/queren?id=" + id + '&is_crate=' + is_crate + '&group_id=' + group_id,
        })
      }

      //  if(res.data.status == 1){
      //    wx.navigateTo({
      //     url:"../queren/queren?id=" + id + '&is_crate=' + is_crate + '&group_id=' + group_id,
      //   })
      // }

    })
    
  },
  // 参团
  joinTeam:function(e){
    var group_id = e.currentTarget.dataset.goodsId;
    var id = this.data.id;
    // console.log(group_id)
     var wxtoken = wx.getStorageSync('wxtoken');

     server.getJSON('/Order/checkjoin/wxtoken/' + wxtoken + '/id/' + group_id,function(res){
      if(res.data.status == 0){
        wx.showToast({
          title:res.data.msg,
          icon:'none'
        })
      }else{
         wx.navigateTo({
          url:"../collage_detail/collage_detail?id=" + id + '&group_id=' + group_id,
        })
      }

    })
   
    
  },

});