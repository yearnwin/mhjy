var server = require('../../../utils/server');
var app = getApp();
Page({
  data: {
    shows: 0,

    showTopTips: false,

    radioItems: [
      { name: 'cell standard', value: '0' },
      { name: 'cell standard', value: '1', checked: true }
    ],
    checkboxItems: [
      { name: 'standard is dealt for u.', value: '0', checked: true },

    ],

    date: "2016-09-01",
    time: "12:01",

    countryCodes: ["+86", "+80", "+84", "+87"],
    countryCodeIndex: 0,

    countries: ["中国", "美国", "英国"],
    countryIndex: 0,

    accounts: ["微信号", "QQ", "Email"],
    accountIndex: 0,

    isAgree: false,
    img:'',
    goods_name:'',
    team_price:0,
    address_id:0, 
    consignee:'',
    mobile:'',
    address:'',
    amount:0,
    is_crate:1,
    group_id:0,
    id:0,

  },
  // 打开优惠券
  switch1Change: function (e) {
    this.setData({
      shows: e.detail.value
    });
  },
  onLoad:function(options){
    var id = options.id;
    var group_id = options.group_id;
    var is_crate = options.is_crate;
    var that = this;

    server.getJSON('/LoginApi/group_goods/id/' + id,function(res){
      var list = res.data.list;
      that.setData({
        list:list,
        id :id,
        group_id :group_id,
        is_crate :is_crate,
      });
    })
    that.getAddress(0);

  },
  getAddress:function(){
    var that=this;

    server.getJSON('/Order/groupaddress/wxtoken/' + wx.getStorageSync('wxtoken'),function(res){
      var address_id=res.data.list.address_id;
      if(res.data.status == 1){
        that.setData({
          consignee:res.data.list.consignee,
          mobile:res.data.list.mobile,
          address_id:res.data.list.address_id,
          address:res.data.list.province+res.data.list.city+res.data.list.district+res.data.list.address,
        });
      }
 
    });
  },
  address_list:function(){
    wx.navigateTo({
      url: "../../wode/address_manage/address_manage?goType=2&id=" + this.data.id + '&is_crate=' + this.data.is_crate + '&group_id=' + this.data.group_id,
    });

  },
  team_order:function(){
    var that = this;
    // console.log(that.data.id)
    var team_price = that.data.list.team_price;

    wx.request({
      url: app.globalData.url + '/wxapi/Order/addgroup',
      data: {
        id: that.data.id,
        is_crate:that.data.is_crate,
        group_id:that.data.group_id,
        address_id:that.data.address_id,
        wxtoken:wx.getStorageSync('wxtoken'),
      },
      method: 'POST',
      success(res) {
        // console.log(res.data)
        if (res.data.status == 1) {
          var objectId = that.data.id;
          var id = res.data.data.id;
          var group_goodsid =res.data.data.group_goodsid;
          var group_id =res.data.data.group_id;
          var order_sn =res.data.data.order_sn;
          var paymoney = team_price;
          var user =res.data.data.userid;
            wx.navigateTo({
              url: '../pay/pay?amount=' + paymoney +'&payurl=1' + '&id=' + id + '&objectId=' +objectId + '&order_sn=' + order_sn+ '&group_id=' +group_id + '&user=' + user,
            })
        }
        if (res.data.status == -1) {
            wx.showToast({
              title:res.data.msg,
              icon:'none',
            })
        }
         if (res.data.status == 0) {
            wx.showToast({
              title:res.data.msg,
              icon:'none',
            })
        }
      }
    });
  },

});