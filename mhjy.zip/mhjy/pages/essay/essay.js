// pages/essay/essay.js
var server = require('../../utils/server');
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        url: app.globalData.url,
        goods_list: null,
    },
    // 跳转详情页面
    goessaydet: function(e) {
        let id = e.currentTarget.dataset.myid
        wx.navigateTo({
            url: '../essaydet/essaydet?objectId=' + id
        })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        // console.log(options)
        var that = this;
        that.setData({
            id: options.objectId,
        })
        that.articleList();
    },
    //文章列表
    articleList: function(id) {
        var that = this
        // var unionId = app.globalData.unionid;
        var cateId = that.data.id;
        wx.request({
            url: app.globalData.url + '/wxapi/Article/article_list/id/' + cateId,
            data: {
                wxtoken: wx.getStorageSync('wxtoken'),
                id: cateId,
            },
            method: 'POST',
            success: function(res) {
                console.log(res.data.list)
                if (res.data.list != '') {
                    var goods_list = res.data.list;
                    // console.log(goods_list)
                    that.setData({
                        goods_list: goods_list
                    });
                }
            }
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})