// pages/essaydet/essaydet.js
var server = require('../../utils/server');
var app = getApp();
var WxParse = require('../../wxParse/wxParse.js');

Page({

    /**
     * 页面的初始数据
     */
    data: {
        content: '',
        article: null,
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        // console.log(options)
        var that = this;
        that.setData({
            id: options.objectId,
        })
        that.detail();
    },
    detail: function(id) {
        var that = this
        // var unionId = app.globalData.unionid;
        var id = that.data.id;
        wx.request({
            url: app.globalData.url + '/wxapi/Article/detail/id/' + id,
            data: {
                wxtoken: wx.getStorageSync('wxtoken'),
                id: id,
            },
            method: 'POST',
            success: function(res) {
                // console.log(res.data.info)
                if (res.data.info != '') {
                    var content = res.data.info.content;

                    var article = res.data.info;
                    var article1 = res.data.info;
                    console.log(article)
                    console.log(content)
                    that.setData({
                        article: article,
                        content: content

                    });
                    WxParse.wxParse('article1', 'html', that.data.content, that, 5);

                }
            }
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})