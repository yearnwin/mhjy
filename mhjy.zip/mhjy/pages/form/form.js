var server = require('../../utils/server');
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        index: 0,
        array: ['请选择','汉族', '汉族', '汉族', '汉族'],
        sex: ['请选择','男','女'],
        sexindex:0,
        date: '请选择',
        username:'',
        idcard:'',
        mobile:'',
        nation:'',
        address:'',
        email:'',
      contact: '',
        contactname:'',
    },
    bindPickerChange: function (e) {
        // console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
            index: e.detail.value
        })
    },
    bindDateChange: function (e) {
        // console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
            date: e.detail.value
        })
    },
  userInfo: function () {
    var wxtoken = wx.getStorageSync('wxtoken');
    server.getJSON('/Cart/users/wxtoken/' + wxtoken, function (res) {
      if (res.data.status == -1) {
        wx.navigateTo({
          url: '../../wode/choice/choice',
        })
      }
    })
  },

  getUsername: function (e) {
    // console.log(e.detail)
    this.setData({
      username: e.detail.value,
    });
  },
  getMobile: function (e) {
    this.setData({
      mobile: e.detail.value,
    });
  },
  getSex: function (e) {
    this.setData({
      sexindex: e.detail.value,
    });
  },
  getNation: function (e) {
    this.setData({
      nation: e.detail.value,
    });
  },
  getAddress: function (e) {
    this.setData({
      address: e.detail.value,
    });
  },
  getEmail: function (e) {
    this.setData({
      email: e.detail.value,
    });
  },
  getIdCard: function (e) {
    this.setData({
      idcard: e.detail.value,
    });
  },
  getContact: function (e) {
    this.setData({
      contact: e.detail.value,
    });
  },
  getContactName:function(e){
    this.setData({
      contactname: e.detail.value,
    });
  },
  
  isPanter: function () {
    var that = this;
    var username = that.data.username;
    var mobile = that.data.mobile;
    var sex = that.data.sex;
    var nation = that.data.nation;
    var address = that.data.address;
    var email = that.data.email;
    var idcard = that.data.idcard;
    var contact = that.data.contact;
    var contactname = that.data.contactname;
    var date = that.data.date;
    // console.log(username);
    // console.log(mobile);
    if (username == '') {
      wx.showToast({
        title: '请输入姓名',
      })
    } else if (mobile == '') {
      wx.showToast({
        title: '请输入手机号',
      })
    }



     else if (sex == '') {
      // wx.showToast({
      //   title: '请输入性别',
      // })
      sex='男'
    }
     else if (nation == '') {
      // wx.showToast({
      //   title: '请输入民族',
      // })
      nation='汉';
    } 
    else if (email == '') {
      // wx.showToast({
      //   title: '请输入邮箱',
      // })
      email='未填写';
    } 
    
    else if (date == '') {
      // wx.showToast({
      //   title: '请选择日期',
      // })
      data='未选择';
    } 


    else if (address == '') {
      wx.showToast({
        title: '请输入具体住址',
      })
    } 
    else {
      server.getJSON('/User/paidang/wxtoken/' + wx.getStorageSync('wxtoken') + '/username/' + username + '/mobile/' + mobile + '/sex/' + sex + '/address/' + address + '/date/' + date + '/email/' + email + '/contact/' + contact + '/contactname/' + contactname + '/nation/' + nation + '/idcard/' + idcard, function (res) {
        
        wx.showToast({
          title: res.data.msg,
        })
        if(res.data.status == 1){
          wx.showToast({
            title: res.data.msg,
          })
          wx.navigateTo({
            url: '../goods/details/details',
          })
        }else{
          wx.showToast({
            title: res.data.msg,
          })
        }

      });
    }
  }
})