var server = require('../../../utils/server');
var WxParse = require('../../../wxParse/wxParse.js');
var app = getApp();
Page({
  data: {
    url: ''
  },


  onLoad: function (options) {
    this.setData({
      url:options.objectId
    })
  },
  onShareAppMessage: function () {
    return {
      title: '美好家园苹果部落',
      desc: '美好家园苹果部落',
      path: '/pages/index/index'
    }
  },
   //下拉刷新
  onPullDownRefresh:function()
  {
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
  },







  
});