// pages/goods/collect/collect.js
var server = require('../../../utils/server');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goods_list: [],
    url: app.globalData.url,
    p:1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getGoodsList();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function () {

  // },
  getGoodsList: function() {
    var that = this;
    server.getJSON('/User/collect_list/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      // console.log(res);
      if (res.data.status == 1) {
        var goods_list = res.data.result.list;
        that.setData({
          goods_list: goods_list,
        });
      } else if (res.data.status == -1) {
        wx.navigateTo({
          url: '../../wode/choice/choice',
        })
      }
      
    });
  },
  // 删除
  deleteGoods: function (e) {
    var that = this;
    var collectId = e.currentTarget.dataset.collectId;
    server.getJSON('/User/cancel_collect/wxtoken/' + wx.getStorageSync('wxtoken') + '/collect_id/' + collectId, function (res) {
      that.getGoodsList();
    });
  },
  showDetail: function (e) {
    var goodsId = e.currentTarget.dataset.goodsId;
    wx.navigateTo({
      url: "../details/details?objectId=" + goodsId
    });
  },
  //上拉刷新
  onReachBottom: function () {
    var that = this
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
    var p = that.data.p + 1;
    that.setData({
      p: p
    })
    server.getJSON('/User/collect_list/wxtoken/' + wx.getStorageSync('wxtoken') +'/p/'+that.data.p,function(res){ 
      var len=res.data.result.list.length;

      if(len>0){
        that.setData({
          goods_list:that.data.goods_list.concat(res.data.result.list),
        });
      }
    })
  },


  // 下拉刷新
  onPullDownRefresh:function(){
    var that = this
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
    that.setData({
      p: 1
    })
    this.getGoodsList();
  }
})