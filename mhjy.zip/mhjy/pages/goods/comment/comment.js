var server = require('../../../utils/server');
var WxParse = require('../../../wxParse/wxParse.js');
var app = getApp();
Page({
  data: {
    tabStates: [true, false, false],
    tabClasss: ["text-select", "text-normal", "text-normal"],
    tab: 0,
    comment_list: [],
    p:1,
    index:0

  },
  onLoad: function (options) {
    this.getCommentOrder(0);
  },
  tabClick: function (e) {
    var index = e.currentTarget.dataset.index
    var classs = ["text-normal", "text-normal", "text-normal"]
    classs[index] = "text-select"
    this.setData({ tabClasss: classs, tab: index })
    this.getCommentOrder(index);
  },

  // onShareAppMessage: function () {
  //   return {
  //     title: '美好家园苹果部落',
  //     desc: '美好家园苹果部落',
  //     path: '/pages/index/index/'
  //   }
  // },
  //立即评价
  nowJudge: function (e) {
    console.log('立即评价');
    var recId = e.currentTarget.dataset.recId;
    wx.navigateTo({
      url: '../../wode/pingjia/pingjia?recId=' + recId,
    })
  },
  // 初始数据
  getCommentOrder: function (index) {
    var that = this;
    server.getJSON('/Order/comment/wxtoken/' + wx.getStorageSync('wxtoken') + '/status/' + index, function (res) {
      if (res.data.status == 1) {
        var comment_list = res.data.list;
        that.setData({
          comment_list: comment_list
        })
      }
    })

  },
//商品详情
goods_det:function(e){
  var goodsId = e.currentTarget.dataset.goodsId;
  wx.navigateTo({
    url: "../details/details?objectId=" + goodsId
  });

},
 





   //上拉刷新
 onReachBottom: function () {
   var that = this
       wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
           
         server.getJSON('/Goods/goods_list/id/'+this.data.id+'/p/'+this.data.p,function(res){ 
          var len=res.data.result.list.length;
          console.log(len);
          if(len>0){
              that.setData({
                goods_list:res.data.result.list,
                p:that.data.p+1
                });
          }
            
        })
  },



      // 下拉刷新
      onPullDownRefresh:function(){
         var that = this
       wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
           
         server.getJSON('/Goods/goods_list/id/'+this.data.id+'/p/'+this.data.p,function(res){ 
          var len=res.data.result.list.length;
          console.log(len);
          if(len>0){
              that.setData({
                goods_list:res.data.result.list,
                p:that.data.p+1
                });
          }
            
        })
      }













});

