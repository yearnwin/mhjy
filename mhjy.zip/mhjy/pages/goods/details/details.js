var server = require('../../../utils/server');
var WxParse = require('../../../wxParse/wxParse.js');
var app = getApp();
Page({
  data: {
    goods: {},

    current: 0,
    tabStates: [true, false, false],
    tabClasss: ["text-select", "text-normal", "text-normal"],
    galleryHeight: getApp().screenWidth,
    tab: 0,
    goods_num: 1,
    textStates: ["view-btns-text-normal", "view-btns-text-select"],
    article: '<div>我是HTML代码</div>',
    goods_info: [],
    collect: '',
    src: '',
    src1: '',
    suppliers_id:'',

    pic_list: {},
    item_id: '',
    shop_price: '',
    market_price: '',
    store_count: '',
    comment: {},
    commentnum: '0',
    comment_list: {},
    url: app.globalData.url,

    end_time: '',
    activity_is_on: 0,
    goods_prom_type: '',
    activity_title: '',
    start_time: '',
    activity_type: '',
    overtime: '',
   
    indicatorDots: true,  //小点

    autoplay: true,  //是否自动轮播

    interval: 3000,  //间隔时间

    duration: 300,  //滑动时间

    identity: 0,//身份，0大众，1拍档，2社区店
    supplier:'',

    goods_type: 0,//商品类型，0普通，1社区商城商品

    img: '../../../image/xingxing_k.png',

    user_id: '',

    goods_id: '',

    cart_num: 0,

    flag: true,

    goods_num: 1,
  },
  propClick: function (e) {
    var pos = e.currentTarget.dataset.pos;
    var index = e.currentTarget.dataset.index;
    var goods = this.data.goods
    for (var i = 0; i < goods.goods.goods_spec_list[index].length; i++) {

      if (i == pos)
        goods.goods.goods_spec_list[index][pos].isClick = 1;
      else
        goods.goods.goods_spec_list[index][i].isClick = 0;
    }

    this.setData({ goods: goods });
    this.checkPrice();
  },
  // 收藏
  addCollect: function (e) {
    var that = this;
    var goods_id = e.currentTarget.dataset.id;
    var img1 = '../../../image/xingxing_s.png';
    console.log(goods_id)
    if (wx.getStorageSync('wxtoken') == '') {
      wx.navigateTo({
        url: '../../wode/choice/choice',
      })
      return;
    }
    // var unionid = app.globalData.unionId;
    server.getJSON('/Goods/collect_goods/wxtoken/' + wx.getStorageSync('wxtoken') + "/goods_id/" + goods_id, function (res) {
      console.log(res.data)
      if (res.data.status == 1) {
        wx.showToast({
          title: '已收藏',
        })
        that.setData({
          img: img1
        })
      }
      if (res.data.status == 110) {
        wx.navigateTo({
          url: '../../wode/choice/choice',
        })
      }
      if (res.data.status == -3) {

        wx.showToast({
          title: '已收藏',
        })
      }


    });
  },
  kefu: function () {
    wx.navigateTo({
      url: '../../other/kefu/kefu',
    })
  },

  bindMinus: function (e) {

    var num = this.data.goods_num;
    if (num > 1) {
      num--;
    }

    this.setData({ goods_num: num });
  },
  bindManual: function (e) {
    var index = parseInt(e.currentTarget.dataset.index);
    var num = e.detail.value;
    this.setData({ goods_num: num });
  },
  bindPlus: function (e) {
    var num = this.data.goods_num;
    num++;
    this.setData({ goods_num: num });
  },
  onLoad: function (options) {
    // console.log(options)
    var goodsId = options.objectId;
    var first_leader = options.first_leader;
    wx.setStorageSync('app_send_user_id', first_leader);//緩存--从微信分享过来--绑定上下线关系
    this.setData({
      goods_id: goodsId
    })
    if(options.scene){
      app.globalData.uid = options.scene;
    }
    if(app.globalData.user_id==''){
      wx.showToast({
        title: '还没有登录',
        duration: 3000,
        success: function () {
          setTimeout(function () {
            wx.redirectTo({
              url: '../wode/choice/choice',
            })
          }, 2000) //延迟时间
        }
      })
    }
  

  },

  onShow: function () {
    this.getGoodsById();
    this.getGoodsComment();
    this.userInfo();
    this.getCartNum();
  },

  // 购物车商品数量
  getCartNum: function () {
    var that = this;
    var wxtoken = wx.getStorageSync('wxtoken');
    server.getJSON('/Cart/header_cart_list/wxtoken/' + wxtoken, function (res) {
      if (res.data.status == 1) {
        that.setData({
          cart_num: res.data.cartPriceInfo.goods_num
        })
      }
    })
  },

  getSend: function () {
    if (wx.getStorageInfoSync('app_send_user_id')) {
      wx.navigateTo({
        url: '../../wode/choice/choice',
      })
    }
  },

  userInfo: function () {
    var that = this;
    var wxtoken = wx.getStorageSync('wxtoken');
    server.getJSON('/Cart/users/wxtoken/' + wxtoken, function (res) {
      if (res.data.status == 1) {
        wx.setStorageSync('app_send_user_id', '');
        that.setData({
          user_id: res.data.user.user_id
        })
      }
    })
  },

  tabClick: function (e) {
    var index = e.currentTarget.dataset.index
    var classs = ["text-normal", "text-normal", "text-normal"]
    classs[index] = "text-select"
    this.setData({ tabClasss: classs, tab: index })
  },
  // 商品
  getGoodsById: function () {
    var that = this
    // var unionid = app.globalData.unionId;
    var goodsId = that.data.goods_id;
    server.getJSON('/Goods/goodsInfo/id/' + goodsId + '/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      // console.log(res)
      var goodsInfo = res.data.result.list;
      var pic_list = res.data.result.goods_images_nk;
      var commentnum = res.data.result.commentStatistics.c0;
      var collect = res.data.result.collect;
      that.setData({
        goods: goodsInfo,
        pic_list: pic_list,
        commentnum: commentnum,
        collect: collect,
        shop_price: res.data.result.list.shop_price,
        market: res.data.result.list.market_price,
        store_count: res.data.result.list.store_count,
        identity: res.data.result.identity,
        goods_type: res.data.result.goods_type,
      });
      if (res.data.result.filter_spec != '') {
        var item_id = res.data.result.filter_spec[0].lists[0].item_id;
        that.setData({
          item_id: item_id,
        });
      }
      that.initGoodsPrice(goodsId, item_id);
      WxParse.wxParse('article', 'html', that.data.goods.goods_content, that, 5);
    });
  },
  // 活动
  initGoodsPrice: function (goodsId, item_id) {
    var that = this
    // var unionid = app.globalData.unionId;
    server.getJSON('/Goods/activity/goods_id/' + goodsId + '/wxtoken/' + wx.getStorageSync('wxtoken') + '/item_id/' + item_id + 'goods_num/1', function (res) {
      var shop_price = res.data.result.goods.shop_price;
      var market_price = res.data.result.goods.market_price;
      var activity_is_on = res.data.result.goods.activity_is_on;
      var goods_prom_type = res.data.result.goods.prom_type;
      var activity_title = res.data.result.goods.activity_title;
      var start_time = res.data.result.goods.start_time;
      var end_time = res.data.result.goods.end_time;
      var type_nk = res.data.result.goods.type;
      console.log('shopprice');
      console.log(res.data.result.goods);
      that.setData({
        shop_price: shop_price,
        market_price: market_price,
        activity_is_on: activity_is_on,
        goods_prom_type: goods_prom_type,
        activity_title: activity_title,
        start_time: start_time,
        end_time: end_time
      });
      if (activity_is_on = 0) {
        // that.flashTime();
      } else {
        if (goods_prom_type == 0) {

        } else if (goods_prom_type == 1) {
          that.setData({
            activity_type: '限时抢购'
          })
          that.flashTime();
        } else if (goods_prom_type == 3) {
          if (type_nk == 7) {
            that.setData({
              activity_type: '满' + res.data.result.goods.full_money + '减' + res.data.result.goods.expression
            })
          } else {
            that.setData({
              activity_type: '优惠促销'
            })
          }
          that.flashTime();
        }
      }
    });
  },
  // 后动倒计时
  flashTime: function () {
    var that = this;
    var totalSecond = that.data.end_time - Date.parse(new Date()) / 1000;
    var interval = setInterval(function () {
      var second = totalSecond;

      var day = Math.floor(second / 3600 / 24);
      var dayStr = day.toString();
      if (dayStr.length == 1) dayStr = '0' + dayStr;

      var hr = Math.floor((second - day * 3600 * 24) / 3600);
      var hrStr = hr.toString();
      if (hrStr.length == 1) hrStr = '0' + hrStr;

      var min = Math.floor((second - day * 3600 * 24 - hr * 3600) / 60);
      var minStr = min.toString();
      if (minStr.length == 1) minStr = '0' + minStr;

      var sec = second - day * 3600 * 24 - hr * 3600 - min * 60;
      var secStr = sec.toString();
      if (secStr.length == 1) secStr = '0' + secStr;

      that.setData({
        overtime: dayStr + '天' + hrStr + '时' + minStr + '分' + secStr + '秒',
      });
      totalSecond--;
      if (totalSecond < 0) {
        clearInterval(interval);
        that.setData({
          overtime: '00天00时00分00秒',
        });
      }

    }.bind(this), 1000);
  },
  // 评价
  getGoodsComment: function () {
    var that = this;
    var goodsId = that.data.goods_id;
    server.getJSON('/Goods/ajaxComment/goods_id/' + goodsId, function (res) {
      var comment = res.data.result.comment_one;
      var comment_list = res.data.result.list;
      that.setData({
        comment_list: comment_list,
        comment: comment
      });
    });
  },

  checkPrice: function () {
    var goods = this.data.goods;
    var spec = ""
    this.setData({ price: goods.goods.shop_price, store_count: goods.goods.store_count });
    for (var i = 0; i < goods.goods.goods_spec_list.length; i++) {
      for (var j = 0; j < goods.goods.goods_spec_list[i].length; j++) {
        if (goods.goods.goods_spec_list[i][j].isClick == 1) {
          if (spec == "")
            spec = goods.goods.goods_spec_list[i][j].item_id
          else
            spec = spec + "_" + goods.goods.goods_spec_list[i][j].item_id
        }
      }
    }
    var specs = spec.split("_");
    for (var i = 0; i < specs.length; i++) {
      specs[i] = parseInt(specs[i])
    }
    specs.sort(function (a, b) { return a - b });
    spec = ""
    for (var i = 0; i < specs.length; i++) {
      if (spec == "")
        spec = specs[i]
      else
        spec = spec + "_" + specs[i]
    }
    var price = goods['spec_goods_price'][spec].price;
    var store_count = goods['spec_goods_price'][spec].store_count;
    this.setData({ price: price, store_count: store_count });
  },

  buyNow: function () {
    var item_id = this.data.item_id;
    var goods_id = this.data.goods.goods_id;
    var suppliers_id = this.data.goods.suppliers_id;
    var goods_type = this.data.goods_type;
    var goods_num = this.data.goods_num;
    var identity = this.data.identity;

    // console.log(this.data)

    //注释绑定手机--2018年10月11日 16:13:42--空灭道

    if (suppliers_id != 0 && identity == 0) {
      wx.navigateTo({
        url: '../../form/form',
      })
     
    } else{
      wx.request({
        url: app.globalData.url + '/wxapi/Cart/cart2',
        data: {
          wxtoken: wx.getStorageSync('wxtoken'),
          item_id: item_id,
          goods_num: goods_num,
          action: 'buy_now',
          goods_id: goods_id,
          suppliers_id:suppliers_id,
        },
        method: 'POST',
        success: function (res) {
          if (res.data.status == 1) {
            wx.navigateTo({
              url: '../../other/queren/queren?action=buy_now&goods_id=' + goods_id + '&goods_num=' + goods_num + '&suppliers_id=' + suppliers_id + '&item_id=' + item_id,
            })
          } else if (res.data.status == 110) {
            wx.navigateTo({
              url: '../../wode/choice/choice',
            })
          } else {
            wx.showToast({
              title: res.data.msg,
            })
          }
        }
      })
    }
  },
  addCart: function () {
    var that = this;
    var goodsId = that.data.goods_id;
    var suppliers_id = that.data.suppliers_id;
    var item_id = that.data.item_id;
    var goods_type = that.data.goods_type;
    var identity = that.data.identity;
    var goods_num = that.data.goods_num;
    // if (wx.getStorageSync('wxtoken') == '') {
    //   wx.navigateTo({
    //     url: '../../wode/choice/choice',
    //   })
    //   return;
    // }
    if (suppliers_id != 0 && identity == 0) {
      wx.navigateTo({
        url: '../../form/from',
      })
      
    } else{
      server.getJSON('/Cart/ajaxAddCart/goods_id/' + goodsId + '/goods_num/1/' + 'wxtoken/' + wx.getStorageSync('wxtoken') + '/item_id/' + item_id + '&suppliers_id=' + suppliers_id, function (res) {
        if (res.data.status == 110) {
          wx.navigateTo({
            url: '../../wode/choice/choice',
          })
        } else {
          // console.log(res.data.result)
          that.setData({
            cart_num: res.data.result,
          })
          wx.showToast({
            title: res.data.msg,
          })
        }
      });
    }

  },
  // 去购物车
  showCart: function () {
    if (wx.getStorageSync('wxtoken') == '') {
      wx.navigateTo({
        url: '../../wode/choice/choice',
      })
      return;
    }
    wx.switchTab({
      url: '../../cart/cart'
    });
  },
  index: function () {
    wx.switchTab({
      url: '../../index/index',
    })
  },
  showCartToast: function () {
    wx.showToast({
      title: '已加入购物车',
      icon: 'success',
      duration: 1000
    });
    wx.navigateTo({
      url: '../../../../../../cart/cart'
    });
  },
  previewImage: function (e) {
    wx.previewImage({
      //从<image>的data-current取到current，得到String类型的url路径
      current: this.data.goods.get('images')[parseInt(e.currentTarget.dataset.current)],
      urls: this.data.goods.get('images') // 需要预览的图片http链接列表
    })
  },

  onShareAppMessage: function () {
    // console.log(this.data)
    var goods_id = this.data.goods.goods_id;
    var scene = app.globalData.user_id;
    var img = this.data.goods.img;
    var goods_name = this.data.goods.goods_name;
    var user_id = this.data.user_id;

    return {
      title: goods_name,
      desc: '美好家园苹果部落',
      imageUrl: img,
      path: '/pages/goods/details/details?objectId=' + goods_id + '&scene=' + scene + '&first_leader=' + user_id
    }
  },

  promShow: function () {
    this.setData({ flag: false })
  },

  b: function () {
    this.setData({ flag: true })
  }

});

