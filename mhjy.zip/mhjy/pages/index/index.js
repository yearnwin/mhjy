//index.js
//获取应用实例
var server = require('../../utils/server');
var WxParse = require('../../wxParse/wxParse.js');
var app = getApp();
Page({
    data: {
        user_id: '',
        banner: [],
        nav: [],
        name1: '特惠专区',
        ad_pic: '',
        flash_sale: [],
        category_goods: [],
        prom_goods: [],
        over_time: '',
        time_d: '00',
        time_h: '00',
        time_m: '00',
        time_s: '00',
        indicatorDots: true,
        vertical: false,
        autoplay: true,
        interval: 3000,  //间隔时间
        duration: 3000,  //滑动时间

        indicatorDots: true,  //小点

        autoplay: true,  //是否自动轮播

        interval: 3000,  //间隔时间

        duration: 300,  //滑动时间

    },

    //事件处理函
    onLoad: function (options) {
        
        if (options.scene) {
          var scene = decodeURIComponent(options.scene);
          console.log(scene);
          app.globalData.uid = options.scene;
          // wx.showToast({
          //   title: scene,
          // })
          // wx.showToast({
          //   title: option.scene,
          // })
          // 备用收到的uid
          // server.getJSON('/user/app/scene/' + scene + '/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
          //   console.log('接收到的数据');
          //   console.log(res);
          //   console.log('自己的微信token');
          //   console.log(wx.getStorageSync('wxtoken'));
          //   wx.showToast({
          //     title: res.data.msg,
          //   })
          // })
        }
      

    

        // if(app.globalData.user_id==''){
        //   wx.showToast({
        //     title: '还没有登录',
        //     duration: 3000,
        //     success: function () {
        //       setTimeout(function () {
        //         wx.redirectTo({
        //           url: '../wode/choice/choice',
        //         })
        //       }, 2000) //延迟时间
        //     }
        //   })
          
        // }
    

        if (app.globalData.userInfo) {
            this.setData({
                userInfo: app.globalData.userInfo,
                hasUserInfo: true,
            })
        } else if (this.data.canIUse) {
            // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
            // 所以此处加入 callback 以防止这种情况
            app.userInfoReadyCallback = res => {
                this.setData({
                    userInfo: res.userInfo,
                    hasUserInfo: true
                })
            }
        } else {
            // 在没有 open-type=getUserInfo 版本的兼容处理
            wx.getUserInfo({
                success: res => {
                    app.globalData.userInfo = res.userInfo
                    this.setData({
                        userInfo: res.userInfo,
                        hasUserInfo: true
                    });
                    // console.log(res.userInfo)
                }
            })
        }
    },

    onShow: function () {
        this.loadBanner();
        this.userInfo();
    },


    getUserInfo: function (e) {
        // console.log(e)
        app.globalData.userInfo = e.detail.userInfo
        this.setData({
            userInfo: e.detail.userInfo,
            hasUserInfo: true
        })
    },

    userInfo: function () {
        var that = this;
        var wxtoken = wx.getStorageSync('wxtoken');
        console.log('wxtoken');
        console.log(wxtoken);
        server.getJSON('/Cart/users/wxtoken/' + wxtoken, function (res) {
       
            if (res.data.status == 1) {
                wx.setStorageSync('app_send_user_id', '');
              app.globalData.user_id = res.data.user.user_id
                that.setData({
                    user_id: res.data.user.user_id
                })
            }
        })
    },


    loadBanner: function () {
        var that = this;
        server.getJSON("/Index/index", function (res) {
            console.log(res.data.result.count);
            var banner = res.data.result.banner;
            var nav = res.data.result.nav;
            // console.log(nav)
            var flash_sale = res.data.result.flash_sale;
            console.log(flash_sale)
            var category_goods = res.data.result.category_goods;
            console.log(category_goods)
            for (var i = 0; i < category_goods.length;i++){
                for (var j = 0; j < category_goods[i].goods.length; j++) {
                    category_goods[i].goods[j].shop_price = Math.floor(category_goods[i].goods[j].shop_price);     
                }               
            }
            var prom_goods = res.data.result.prom;
            var over_time = res.data.result.over_time;
            var name1 = res.data.result.name1;
            var ad_pic = res.data.result.ad_pic;
            that.setData({
                banner : banner,
                nav: nav,
                flash_sale: flash_sale,
                category_goods: category_goods,
                prom_goods: prom_goods,
                over_time: over_time,
                // name1:name1,
                ad_pic: ad_pic,
            });
            that.flashTime();
        });
    },

    onReady: function () {

    },

    flashTime: function () {
        var that = this;
        var over_time_nk = that.data.over_time;
        var totalSecond = over_time_nk - Date.parse(new Date()) / 1000;
        var interval = setInterval(function () {
            var second = totalSecond;

            var day = Math.floor(second / 3600 / 24);
            var dayStr = day.toString();
            if (dayStr.length == 1) dayStr = '0' + dayStr;

            var hr = Math.floor((second - day * 3600 * 24) / 3600);
            var hrStr = hr.toString();
            if (hrStr.length == 1) hrStr = '0' + hrStr;

            var min = Math.floor((second - day * 3600 * 24 - hr * 3600) / 60);
            var minStr = min.toString();
            if (minStr.length == 1) minStr = '0' + minStr;

            var sec = second - day * 3600 * 24 - hr * 3600 - min * 60;
            var secStr = sec.toString();
            if (secStr.length == 1) secStr = '0' + secStr;

            that.setData({
                time_d: dayStr,
                time_h: hrStr,
                time_m: minStr,
                time_s: secStr,
            });
            totalSecond--;
            if (totalSecond < 0) {
                clearInterval(interval);
                that.setData({
                    time_d: '00',
                    time_h: '00',
                    time_m: '00',
                    time_s: '00',
                });
            }

        }.bind(this), 1000);
    },

    showDetail: function (e) {
        var goodsId = e.currentTarget.dataset.goodsId;
        wx.navigateTo({
            url: "../goods/details/details?objectId=" + goodsId
        });
    },

    flashSale: function (e) {
        wx.switchTab({
            url: '../sale/sale',
        })
    },

    advUrl: function (event) {
        var jump_type = event.currentTarget.dataset.jumpType;
        var jump_url = event.currentTarget.dataset.jumpUrl;

        if (jump_type == 0) {
            wx.navigateTo({
                url: "../goods/ceshi/ceshi?objectId=" + jump_url,
            });
        } else if (jump_type == 1) {
            wx.navigateTo({
                url: "../goods/details/details?objectId=" + jump_url,
            });
        } else if (jump_type == 2) {
            wx.navigateTo({
                url: "../goods/list/list?objectId=" + jump_url,
            });
        } else {
            url: "../goods/activity_goods/activity_goods?objectId=" + jump_url
        }
    },

    goodsCate: function (e) {
        var cateId = e.currentTarget.dataset.cateId;
        wx.navigateTo({
            url: "../goods/list/list?objectId=" + cateId,
        });
    },
    eleven: function (e) {
        var cateId = e.currentTarget.dataset.cateId;
        wx.navigateTo({
            url: "../goods/eleven/eleven?objectId=" + cateId,
        });
    },

    showCategor: function (event) {
              // type0指定分类  1特惠专区 flash 2 文章分类 url 1 3区域 supplier 4 个人中心 mine

        var jump_type = event.currentTarget.dataset.jumpType;
        var jump_url = event.currentTarget.dataset.jumpUrl;
      
        // console.log(jump_type)
        if (jump_type == 0) {
            wx.navigateTo({
                url: "../goods/list/list?objectId=" + jump_url,
            });
        } else if (jump_type == 1) {
            wx.navigateTo({
                url: "../goods/activity_goods/activity_goods?objectId=" + jump_url,
            });
        } else if (jump_type == 2) {
          wx.navigateTo({
            // url: "../essay/essay?objectId=" + jump_url,
            url: "../essaydet/essaydet?objectId=" + jump_url,
          });
        } else if (jump_type == 3) {
          wx.navigateTo({
            url: "../mybuyf/mybuyf",
          });
        } else if (jump_type == 4) {
            wx.switchTab({
              url: "../mine/mine?objectId=" + jump_url,
          });
        } else if (jump_type == 5){
            wx.navigateTo({
                // url: '../gohtml2/gohtml2',
                url: "../essay/essay?objectId=" + jump_url,
            })
        }

    },


    // 搜索
    search: function (e) {
        wx.navigateTo({
            url: '../other/search/search',
        })
    },



    // 系统消息
    sys: function () {
        wx.navigateTo({
            url: '../sys/sys',
        })
    },


    //下拉刷新
    onPullDownRefresh: function () {
        wx.showNavigationBarLoading() //在标题栏中显示加载  
        this.loadBanner();
        //模拟加载
        setTimeout(function () {
            wx.hideNavigationBarLoading() //完成停止加载
            wx.stopPullDownRefresh() //停止下拉刷新
        }, 1000);
    },

  /**
* 用户点击右上角分享
*/
  onShareAppMessage: function () {
    // var that = this;
    // var user_id = that.data.user_id;
    // var scene = 1;
    // console.log(app.globalData.user_id);
    return {
      title: '美好家园苹果部落',
      desc: '美好家园苹果部落',
      path: '/pages/index/index?scene=' + app.globalData.user_id
    }
  },

})