//index.js
//获取应用实例
var server = require('../../utils/server');
var app = getApp();
Page({
    data: {
        // userInfo: app.globalData.userInfo,

        head_pic: '../../img/ceshi.jpg',
        nickname: '去登陆',
        user_money: 0,
        pay_point: 0,
        coupon_count: 0,
        waitPay: 0,
        waitReceive: 0,
        uncomment_count: 0,
        return_count: 0,
        waitSend: 0,
        user_cash: 0,
        identity: 0,
        partner: 0,
        levelimg: '../../image/wd_jdt.png',
        like: [],
        url: app.globalData.url,

        login: false,
        onteam: 0,



    },
    onLoad: function (options) {
        console.log('得到的uid');
        console.log(app.globalData.uid);

        // console.log(wx.getStorageSync('wxtoken'));
    },
    onShow: function () {

        this.userInfo();
        this.doYouLike();
    },
    userInfo: function () {
        var that = this;
        server.getJSON('/User/userinfo/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
            if (res.data.status == 1) {

                var info = res.data.result.info;
              console.log('userinfo');
               console.log(info);
              console.log(info.waitPay);
             
                that.setData({
                    nickname       : info.nickname,
                    head_pic       : info.head_pic,
                    coupon_count   : info.coupon_count,
                    pay_point      : info.pay_points,
                    user_money     : info.user_money,
                    user_cash      : info.user_cash,
                    waitPay        : info.waitPay,
                    waitSend       : info.waitSend,
                    waitReceive    : info.waitReceive,
                    return_count   : info.return_count,
                    uncomment_count: info.uncomment_count,
                    identity       : info.identity,
                    partner        : info.partner,
                    levelimg       : info.levelimg,
                    login          : true,
                    onteam         : info.onteam
                });
                console.log('waitpay');
              console.log(that.data.waitPay);

                // console.log(info);
            } else if (res.data.status == -1) {
                that.setData({
                    head_pic: '../../img/ceshi.jpg',
                    nickname: '去登陆',
                    user_money: 0,
                    pay_point: 0,
                    coupon_count: 0,
                    waitPay: 0,
                    waitReceive: 0,
                    uncomment_count: 0,
                    return_count: 0,
                    waitSend: 0,
                    user_cash: 0,
                    identity: 0,
                    partner: 0,
                    levelimg: '../../image/wd_jdt.png',
                    like: [],
                    url: app.globalData.url,
                    login: false,
                    onteam: 0
                })
            }
        });
    },
    // 猜你喜欢
    doYouLike: function () {
        var that = this;
        server.getJSON('/loginApi/doyoulike', function (res) {
            var like = res.data.result.list;
            that.setData({
                like: like
            });
        });
    },
    showDetail: function (e) {
        var goodsId = e.currentTarget.dataset.goodsId;
        wx.navigateTo({
            url: "../goods/details/details?objectId=" + goodsId
        });
    },
    doLogin: function () {
        wx.navigateTo({
            url: '../wode/choice/choice'
        })
    },
    //事件处理函数
    // 优惠券
    couponList: function () {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../other/coupon/coupon'
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }

    },
    // 现金券--奖励金
    credit: function () {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../other/yongjin/yongjin'
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    // 小金库
    cash: function () {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../wode/cash/cash'
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    // 积分
    integralmx: function () {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../other/integralmx/integralmx'
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    // 拍档
    panter: function () {
        var partner = this.data.partner;
        if (this.data.login == true) {
            if (partner == 1) {
                wx.showToast({
                    title: '您已经是拍档了',
                })
            } else {
                wx.navigateTo({
                    url: '../set/chengwei/chengwei'
                })
            }
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    // 商超采购
    mallBuy: function () {
        wx.navigateTo({
            url: '../goods/mall/mall'
        })
    },
    // 大宗采购
    buyCenter: function () {
        wx.navigateTo({
            url: '../goods/buy_center/buy_center'
        })
    },
    // 领券中心
    couponCenter: function () {
        wx.navigateTo({
            url: '../other/collar/collar'
        })
    },
    shoucang: function (e) {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../goods/collect/collect'
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    visit: function (e) {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../goods/visit/visit',
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    erweima: function (e) {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../other/erweima/erweima',
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    gohtml: function(e){
        wx.navigateTo({
            url: '../gohtml/gohtml',
        })
    },

    distribution: function () {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../wode/distribution/distribution',
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },

    myset: function () {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../set/set/set',
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },


    collar: function () {
        wx.navigateTo({
            url: '../other/collar/collar',
        })
    },
    kefu: function () {
        wx.navigateTo({
            url: '../other/kefu/kefu',
        })
    },

    //订单处理
    mydingdan: function (e) {
        var id = e.currentTarget.dataset.status;
        if (this.data.login == true) {
            if (id == 5) {
                //评价页
                wx.navigateTo({

                    url: '../goods/comment/comment',
                })
            } else {
                wx.navigateTo({
                    url: '../wode/mydingdan/mydingdan?id=' + id,
                })
            }
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }


    },
    application_return_list: function () {
        wx.showModal({
            title: '请前往电脑端进行操作',
            content: '网址为：http://www.mhjy.zqcom.cc',
            success: function (res) {
                if (res.confirm) {

                } else if (res.cancel) {

                }
            }
        })

        // wx.navigateTo({
        //   url: '../wode/application_return_list/application_return_list',
        // })
    },


    // getUserInfo: function (e) {
    //   console.log(e)
    //   app.globalData.userInfo = e.detail.userInfo
    //   this.setData({
    //     userInfo: e.detail.userInfo,
    //     hasUserInfo: true
    //   })
    // }


    // 系统消息
    syssetMessage: function () {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../other/stylemessage/stylemessage',
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    // 拼团
    team: function () {
        wx.navigateTo({
            url: '../collage/collage_home/collage_home',
        })
    },
    myApple: function () {
        wx.navigateTo({
            url: '../wode/myapple/myapple',
        })
    },

});