var server = require('../../utils/server');
var WxParse = require('../../wxParse/wxParse.js');
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        url: app.globalData.url,
        picture: '',
        supplier_list: [],
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
      var that =this;
        if (options.user_id) {
            wx.setStorageSync('app_send_user_id', options.user_id);
        }
        that.loadCate();
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    //下拉刷新
    onPullDownRefresh: function () {
        wx.showNavigationBarLoading() //在标题栏中显示加载  
        //模拟加载
        setTimeout(function () {
            wx.hideNavigationBarLoading() //完成停止加载
            wx.stopPullDownRefresh() //停止下拉刷新
        }, 1000);
        this.loadCate();
    },
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
       
    },

    loadCate: function () {
      var that = this;
      wx.request({
        url: app.globalData.url + '/wxapi/Goods/supplier_list',
        data: {
          wxtoken: wx.getStorageSync('wxtoken'),
        },
        method: 'POST',
        success: function (res) {
          console.log(res)
          var supplier_list = res.data.result.list;
          var picture = res.data.result.img;
          that.setData({
            supplier_list: supplier_list,
            picture:picture
          });
        }
      })
    },

    goodsCate: function (e) {
        var Id = e.currentTarget.dataset.cateId;
        // console.log(Id)
        wx.navigateTo({
            url: '../mybuy/mybuy?objectId=' + Id,
        })
    },

    bindViewTap: function (e) {
        var jump_type = e.currentTarget.dataset.jumpType;
        var jump_url = e.currentTarget.dataset.jumpUrl;

        if (jump_type == 0) {
            wx.navigateTo({
                url: "../goods/ceshi/ceshi?objectId=" + jump_url,
            });
        } else if (jump_type == 1) {
            wx.navigateTo({
                url: "../goods/details/details?objectId=" + jump_url,
            });
        } else if (jump_type == 2) {
            wx.navigateTo({
                url: "../goods/list/list?objectId=" + jump_url,
            });
        } else {
            url: "../goods/activity_goods/activity_goods?objectId=" + jump_url
        }
    }
})
