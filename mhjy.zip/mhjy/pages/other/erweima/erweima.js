// pages/other/erweima/erweima.js
var app = getApp();
var server = require('../../../utils/server');

Page({

  /**
   * 页面的初始数据
   */
  data: {
      
      // imgUrl:'',
      // message:'',
      user_id:0,
      nickname:'',
      identity:0,
    wxtoken:  wx.getStorageSync('wxtoken')

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      var that=this;
    server.getJSON('/User/userinfo/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
        // console.log(res.data);
        if (res.data.status == 1) {
          var user_id = res.data.result.info.user_id;
          console.log(user_id)
          var nickname = res.data.result.info.nickname;
          var identity = res.data.result.info.identity;
          that.setData({
            user_id:user_id,
            nickname:nickname,
            identity:identity,

          })

          if (app.globalData.user_id == '') {
            wx.showToast({
              title: '还没有登录',
              duration: 3000,
              success: function () {
                setTimeout(function () {
                  wx.redirectTo({
                    url: '../wode/choice/choice',
                  })
                }, 2000) //延迟时间
              }
            })
          }




          wx.request({
            url: app.globalData.url + '/WXAPI/User/erweimas',
            data: {
              user_id: user_id,
              wxtoken: wx.getStorageSync('wxtoken'),
            },
            success: function (nres) {
              console.log('nres');
              console.log(nres);
              if (nres.data.code == 1) {
                console.log('request');
                that.setData({
                  img_url: nres.data.msg
                })
                var promise1 = new Promise(function (resolve, reject) {
                  wx.getImageInfo({
                    src: nres.data.msg,
                    success: function (res) {
                      console.log('getimg');
                      console.log(res);
                      resolve(res);
                    },

                  });
                })
               
                Promise.all([
                  promise1
                ]).then(res => {
                    console.log(res[0].path)
                  var rpx;
                  //获取屏幕宽度，获取自适应单位
                  wx.getSystemInfo({
                    success: function (res) {
                     
                      rpx = res.windowWidth / 375;
                    },
                  })
                  // console.log(res)
                  var ctx = wx.createCanvasContext('shareImg');
                    ctx.drawImage(res[0].path, 137.5 * rpx, 50 * rpx, 100 * rpx, 100 * rpx)

                  ctx.stroke()
                  wx.showLoading({
                    title: '努力生成中...'
                  }),
                    ctx.draw(true, setTimeout(function () {
                      wx.canvasToTempFilePath({
                        x: 0,
                        y: 0,
                        width: 106,
                        height: 106,
                        destWidth: 106,
                        destHeight: 106,
                        canvasId: 'shareImg',
                        success: function (res) {
                         
                          that.setData({
                            prurl: res.tempFilePath,
                            hidden: false
                          })
                          wx.hideLoading()
                        },
                        fail: function (res) {
                          console.log(res)
                        }
                      })
                    }, 200));
                })
              }
            }
          })




        } else if (res.data.status == -1) {
          wx.navigateTo({
            url: '../../wode/choice/choice',
          })
        }
      });
    // wx.getSetting({
    //   success: function (res) {
    //     // console.log(res)
    //     if (res.authSetting['scope.userInfo']) {
    //       that.setData({
    //         sqhide: 'sqhidec'
    //       });
    //       wx.getUserInfo({
    //         success: ({ userInfo }) => {
    //           // console.log(userInfo)
    //           that.setData({
    //             userInfo: userInfo
    //           });
    //           app.globalData.userInfo.nickName = userInfo.nickName;
    //           app.globalData.userInfo.avatarUrl = userInfo.avatarUrl;
    //           app.globalData.userInfo.user_id = userInfo.user_id;
    //           app.globalData.userInfo.identity = userInfo.identity;
    //         }
    //       })
    //       // console.log(app.globalData)

    //     } else {
    //       wx.showModal({
    //         title: '确认授权',
    //         content: '尚未进行授权，请去授权跳转到授权页面点击微信登录',
    //         confirmText: "去授权",
    //         cancelText: "取消",
    //         success: function (res) {
    //           // console.log(res);
    //           if (res.confirm) {
    //             wx.navigateTo({
    //               url: '../../wode/choice/choice',
    //             })
    //           } else {

    //           }
    //         }
    //       });
    //     }
    //   }
    // })   
      
  },
  onShow: function(options){
    // console.log(options)
    // var that = this;
    // // 调用小程序 API，得到用户信息
    // wx.getUserInfo({
    //   success: ({ userInfo }) => {
    //     that.setData({
    //       userInfo: userInfo
    //     });
    //   }
    // });

  },

  /**
   * 用户点击右上角分享
   */
    onShareAppMessage: function () {
 
      var user_id= app.globalData.user_id;
      var nickname =this.data.nickname;
      var identity =this.data.identity;
      var scene = 1;

    return {
      title: '美好家园苹果部落',
        desc: '美好家园苹果部落',
      path: '/pages/index/index?user_id=' + user_id + '&nickname=' + nickname + '&identity=' + identity + '&scene=' + scene
    }
  },
})