var server = require('../../../utils/server');
var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    shows: false,
    checked: 0,
    action: '',
    address: '',
    goods_list: [],
    coupon_list: [],
    url: app.globalData.url,
    user: '',
    total_fee: 0,
    coupon_id: '',
    user_money: 0,
    can_use_money: 0,
    address_id: '',
    userCouponNum: 0,
    auth_code: 'TPSHOP',
    invoice_title: '个人',
    radio_title: '个人',
    radio_cont: '不开发票',
    pay_points: '',
    couponCode: '',
    payPwd: '',
    user_note: '',
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var goods_id = options.goods_id;
    var item_id = options.item_id;
    var action = options.action;
    var goods_num = options.goods_num;
    var suppliers_id =options.suppliers_id;
    this.setData({
      goods_id: goods_id,
      item_id: item_id,
      action: action,
      goods_num: goods_num,
      suppliers_id:suppliers_id,
    })
 
    this.getCart();
  },


  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  
//下拉刷新
  onPullDownRefresh:function()
  {
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
  },


  addList: function () {
    var that = this;
    that.setData({
      disabled: 0
    })
    var action = that.data.action;
    var goods_id = that.data.goods_id;
    var goods_num = that.data.goods_num;
    var item_id = that.data.item_id;
    wx.navigateTo({
      url: '../../wode/address_manage/address_manage?goType=1&action=' + action + '&goods_id=' + goods_id + '&goods_num=' + goods_num + '&item_id=' + item_id,
    })
  },


 



  
  // 打开-关闭-优惠券
  switch1Change: function (e) {
    var that = this;
    var shows = e.detail.value
    that.setData({
      shows: shows
    });
    if(shows == false){
      that.setData({
        coupon_id: '',
      });
    }
    that.orderPrice();
  },
  // 使用优惠券
  useCoupon: function (e) {
    var that = this;
    var couponId = e.currentTarget.dataset.couponId;
    that.setData({
      coupon_id: couponId,
      total_fee: 0,
    });
    that.orderPrice();
  },
  // 奖励金
  bindCheckbox: function (e) {
    var that = this;
    var checked = e.currentTarget.dataset.index;
    var canUse = e.currentTarget.dataset.canUse;
    that.setData({
      total_fee: 0,
      checked: checked,
      user_money: canUse
    })
    that.orderPrice();
  },
  // 初始数据
  getCart: function () {
    var that = this;
    server.getJSON('/Cart/cart2/wxtoken/' + wx.getStorageSync('wxtoken') + '/action/' + that.data.action + '/goods_id/' + that.data.goods_id + '/goods_num/' + that.data.goods_num + '/item_id/' + that.data.item_id, function (res) {
      if (res.data.status == 1) {
        var goods_list = res.data.result.cartList;
        var coupon_list = res.data.result.userCartCouponList;
        var user = res.data.result.user;
        // console.log('可用奖励金');
        // console.log(user);
        var couponNum = res.data.result.userCouponNum;
        that.setData({
          goods_list: goods_list,
          coupon_list: coupon_list,
          user: user,
          can_use_money: user.user_cash,
          userCouponNum: couponNum.usable_num
        });
        if (res.data.result.address){
          var address = res.data.result.address;
          that.setData({
            address: address,
            address_id: address.address_id,
          })
        }
        that.orderPrice();
      } else {
        wx.showToast({
          title: '抱歉没有商品',
        })
      }
    });
  },

  onShow: function () {
    this.getCart();
  },



  // 计算价格
  orderPrice: function (){
    // console.log(this.data);
    var that = this;
    wx.request({
      url: app.globalData.url + '/wxapi/Cart/cart3',
      data: {
        wxtoken:  wx.getStorageSync('wxtoken'),
        coupon_id: that.data.coupon_id,
        act: 'order_price',
        user_money: that.data.user_money,
        goods_id: that.data.goods_id,
        goods_num: that.data.goods_num,
        item_id: that.data.item_id,
        action: that.data.action
      },
      method: 'POST',
      success(res) {
        if (res.data.status == 1) {
          that.setData({
            total_fee: res.data.result.order_amount
          })
        } else {
          wx.showToast({
            title: res.data.msg
          })
        }
      }
    })
  },
  // 立即购买
  buyNows: function () {

    var that = this;
    console.log('提交的用户约');
    var suppliers_id= that.data.suppliers_id;
    var address_id = that.data.address_id;
    if (address_id == ''){
      wx.showToast({
        title: '请设置收货地址',
      })
    }else{
      wx.request({
        url: app.globalData.url + '/wxapi/Cart/cart3',
        data: {
          wxtoken: wx.getStorageSync('wxtoken'),
          coupon_id: that.data.coupon_id,
          act: 'submit_order',
          user_money: that.data.user_money,
          address_id: address_id,
          goods_id: that.data.goods_id,
          goods_num: that.data.goods_num,
          item_id: that.data.item_id,
          action: that.data.action,
          suppliers_id: suppliers_id,
          total_fee:that.data.total_fee
        },
        method: 'POST',
        success(res) {
          console.log('立即购买');
          console.log(res);
          if (res.data.status == 1) {
            if (res.data.amount == 0) {
              // wx.navigateTo({
              //   url: '../../wode/orderdetails/orderdetails?order_id=' + res.data.id,
              // })
             
              wx.showToast({
                title: '支付成功',
                duration: 3000,
                success: function () {
                  setTimeout(function () {
                    wx.switchTab({
                      url: '../../index/index',
                    })
                  }, 2000) //延迟时间
                }
              })


            } else {
              wx.navigateTo({
                url: '../../other/pay/pay?order_id=' + res.data.id + '&amount=' + res.data.amount + '&payurl=1',
              })
            }
          } else {
            wx.showToast({
              title: res.data.msg
            })
          }
        }
      });
    }
  }
});