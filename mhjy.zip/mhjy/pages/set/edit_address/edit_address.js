// var qqmapsdk;
var server = require('../../../utils/server');
var app = getApp();
Page({
  // isDefault: false,

  data: {
    username: '',
    mobile: '',
    // address: '',
    other_address: '',
    address_id: 0,
    // 地址列表
    prince_list: '',
    city_list: '',
    area_list: '',
    is_default: 0,
    // id
    prince: 0,
    city: 0,
    area: 0,
    // 地址
    prince_name: '',
    city_name: '',
    area_name: '',

    goType: 0,


    // current: 0,
    // province: [],
    // city: [],
    // region: [],
    // town: [],
    // provinceObjects: [],
    // cityObjects: [],
    // regionObjects: [],
    // townObjects: [],
    // areaSelectedStr: '请选择省市区',
    maskVisual: 'hidden',
    // provinceName: '请选择'
  },
  /**
 * 生命周期函数--监听页面加载
 */
  onLoad: function (options) {
    var addressId = options.objectId;
    var goType = options.goType;
    if (goType == 1) {
      this.setData({
        goType: goType
      })
    }
    if (addressId != 0) {
      this.setData({
        address_id: addressId
      })
      this.getAddress(addressId);
    }
  },
  getAddress: function (addressId) {
    var that = this;
    server.getJSON('/User/edit_address/wxtoken/' + wx.getStorageSync('wxtoken') + '/id/' + addressId, function (res) {
      // console.log(res);
      if (res.data.status == 1) {
        var address = res.data.data;
        that.setData({
          username: address.consignee,
          mobile: address.mobile,
          // address: address.provinces + address.citys + address.districts,

          prince_name: address.provinces,
          city_name: address.citys,
          area_name: address.districts,

          prince: address.province,
          city: address.city,
          area: address.district,

          other_address: address.address,
          is_default: address.is_default
        });
      } else {
        wx.showToast({
          title: res.data.msg,
        })
      }
    });
  },

  cascadePopup: function () {
    var animation = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease-in-out',
    });
    this.animation = animation;
    animation.translateY(-285).step();
    this.setData({
      animationData: this.animation.export(),
      maskVisual: 'show'
    });
    this.getPrince();
  },




  cascadeDismiss: function () {
    this.animation.translateY(285).step();
    this.setData({
      animationData: this.animation.export(),
      maskVisual: 'hidden'
    });
  },
  // 姓名
  updateName: function (e) {
    var that = this;
    var username = e.detail.value;
    that.setData({
      username: username
    })
  },
  // 手机号
  updateMobile: function (e) {
    var that = this;
    var mobile = e.detail.value;
    that.setData({
      mobile: mobile
    })
  },
  // 详细地址
  updateAddress: function (e) {
    var that = this;
    var other_address = e.detail.value;
    that.setData({
      other_address: other_address
    })
  },
  // 设为默认地址
  setModel: function (e) {
    var that = this;
    var is_default = e.currentTarget.dataset.defaultId
    console.log(is_default);

    // var other_address = e.detail.value;
    that.setData({
      is_default: is_default
    })
  },

  // 省份展示
  getPrince: function () {
    var that = this;
    wx.request({
      url: app.globalData.url + '/home/Api/getProvince',
      data: {},
      method: 'GET',
      success: function (res) {
        if (res.data.status == 1) {
          var prince_list = res.data.result;
          that.setData({
            prince_list: prince_list,
          })
        }
      }
    })
  },
  // 城市展示
  showCity: function (e) {
    var that = this;
    var province = e.currentTarget.dataset.princeId;
    var province_name = e.currentTarget.dataset.princeName;
    that.setData({
      prince: province,
      prince_name: province_name,
      city_name: '',
      city: 0,
      area_list: '',
      area_name: '',
      area: 0
    })
    wx.request({
      url: app.globalData.url + '/home/Api/getRegionByParentId',
      data: {
        parent_id: province,
      },
      method: 'GET',
      success: function (res) {
        if (res.data.status == 1) {
          var city_list = res.data.result;
          that.setData({
            city_list: city_list,
          })
        }
      }
    })
  },

  // 地区展示
  showArea: function (e) {
    var that = this;
    var city = e.currentTarget.dataset.cityId;
    var city_name = e.currentTarget.dataset.cityName;
    that.setData({
      city: city,
      city_name: city_name,
      area_name: '',
      area: 0
    })
    wx.request({
      url: app.globalData.url + '/home/Api/getRegionByParentId',
      data: {
        parent_id: city,
      },
      method: 'GET',
      success: function (res) {
        if (res.data.status == 1) {
          var area_list = res.data.result;
          that.setData({
            area_list: area_list,
          })
        }
      }
    })
  },
  // 选择地区
  choiceArea: function (e) {
    var that = this;
    var area = e.currentTarget.dataset.areaId;
    var area_name = e.currentTarget.dataset.areaName;
    that.setData({
      area: area,
      area_name: area_name
    })
  },
  // 确认提交
  // 确认提交
  submitAddress: function () {
    var that = this;
    var consignee = that.data.username;
    var mobile = that.data.mobile;
    var address = that.data.other_address;
    var province = that.data.prince;
    var city = that.data.city;
    var district = that.data.area;
    var id = that.data.address_id;
    var is_default = that.data.is_default;
    if (consignee == '' || mobile == '' || address == '') {
      wx.showToast({
        title: '请填写完整信息！',
        icon: 'none',
      })
      return;
    }
    if (province == 0 || city == 0 || district == 0) {
      wx.showToast({
        title: '未选择省市区',
        icon: 'none',
      })
      return;
    }
    var action = '';
    if (id == 0) {
      action = 'add_address';

    } else {
      action = 'edit_address';
    }
    wx.request({
      url: app.globalData.url + '/wxapi/User/' + action,
      data: {
        mobile: mobile,
        consignee: consignee,
        address: address,
        province: province,
        city: city,
        district: district,
        id: id,
        is_default: is_default,
        wxtoken: wx.getStorageSync('wxtoken')
      },
      method: 'POST',
      success: function (res) {
        if (res.data.status == 1) {
          // wx.navigateTo({
          //   url: '../../wode/address_manage/address_manage?goType=' + that.data.goType,
          // })
          wx.navigateBack({
            delta: 1
          })
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
          })
        }
      }
    })
  },
  // 删除地址
  delAddress: function () {
    var that = this;
    var id = that.data.address_id;
    wx.showModal({
      title: '提示',
      content: '是否删除',
      success: function (res) {
        if (res.confirm) {
          // console.log('confirm确定');
          server.getJSON('/user/del_address/wxtoken/' + wx.getStorageSync('wxtoken') + '/id/' + id, function (res) {
            if (res.data.status == 1) {
              wx.navigateTo({
                url: '../../wode/address_manage/address_manage?goType=' + that.data.goType,
              })
            } else {
              wx.showToast({
                title: res.data.msg,
              })
            }
          })
        }
      }
    })
  },

  // regionTapped: function (e) {
  //   // 标识当前点击镇级，记录其名称与主键id都依赖它
  //   var index = e.currentTarget.dataset.index;
  //   // current为1，使得页面向左滑动一页至市级列表
  //   // regionIndex是县级数据的标识
  //   this.setData({
  //     regionIndex: index,
  //     townIndex: -1,
  //     regionName: this.data.region[index],
  //     townName: ''
  //   });
  //   var that = this;
  //   //townObjects是一个LeanCloud对象，通过遍历得到纯字符串数组
  //   // getArea方法是访问网络请求数据，网络访问正常则一个回调function(area){}
  //   this.getArea(this.data.regionObjects[index].get('aid'), function (area) {
  //     // 假如没有镇一级了，关闭悬浮框，并显示地址
  //     if (area.length == 0) {
  //       var areaSelectedStr = that.data.provinceName + that.data.cityName + that.data.regionName;
  //       that.setData({
  //         areaSelectedStr: areaSelectedStr
  //       });
  //       that.cascadeDismiss();
  //       return;
  //     }
  //     var array = [];
  //     for (var i = 0; i < area.length; i++) {
  //       array[i] = area[i].get('name');
  //     }
  //     // region就是wxml中渲染要用到的县级数据，regionObjects是LeanCloud对象，用于县级标识取值
  //     that.setData({
  //       townName: '请选择',
  //       town: array,
  //       townObjects: area
  //     });
  //     // 确保生成了数组数据再移动swiper
  //     that.setData({
  //       current: 3
  //     });
  //   });
  // },
  // townTapped: function (e) {
  //   // 标识当前点击镇级，记录其名称与主键id都依赖它
  //   var index = e.currentTarget.dataset.index;
  //   // townIndex是镇级数据的标识
  //   this.setData({
  //     townIndex: index,
  //     townName: this.data.town[index]
  //   });
  //   var areaSelectedStr = this.data.provinceName + this.data.cityName + this.data.regionName + this.data.townName;
  //   this.setData({
  //     areaSelectedStr: areaSelectedStr
  //   });
  //   this.cascadeDismiss();
  // },

  
// //下拉刷新
//   onPullDownRefresh:function()
//   {
//     wx.showNavigationBarLoading() //在标题栏中显示加载  
//     //模拟加载
//     setTimeout(function()
//     {
//       wx.hideNavigationBarLoading() //完成停止加载
//       wx.stopPullDownRefresh() //停止下拉刷新
//     },1000);
//   },






})