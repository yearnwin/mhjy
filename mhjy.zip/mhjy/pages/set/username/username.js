// pages/set/username/Username.js
var server = require('../../../utils/server');
var app = getApp();
Page({
  data:{
    realname:'',

  },
  onLoad:function(){
    var that = this;
    server.getJSON('/User/userinfo/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      console.log(res.data.result.info);
      var realname = res.data.result.info.realname;
      that.setData({
        realname: realname,

      })

    });
   
  },
    username:function(e){
      var username=e.detail.value.username;
      // console.log(username);
    if (username == '') {
      wx.showToast({
        title: '请输入用户名',
      })
    } else {
      wx.request({
        url: app.globalData.url + '/wxapi/User/userinfo',
        data: {
          wxtoken: wx.getStorageSync('wxtoken'),
          realname: username,
        },
        method: 'POST',
        success(res) {
          if (res.data.status == 1) {
            wx.navigateTo({
              url: '../security/security',
            })
          } else {
            wx.showToast({
              title: res.data.msg
            })
          }
        }
      })
    }
  },

})