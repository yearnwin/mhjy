var server = require('../../../utils/server');
var app = getApp();
Page({
  data: {
    imgUrl: '../../../image/userico.jpg',
    imgType: ''
  },
  // 上传图片接口
  doUpload: function () {
    var that = this
    // 选择图片
    wx.chooseImage({
      success: function (res) {
        wx.getImageInfo({
          src: res.tempFilePaths[0],
          success: function (res) {
            that.setData({
              imgUrl: res.path,
              imgType: res.type
            })
          }
        })
      }
    })
  },

  //修改营业执照
  thumb: function (e) {
    var that = this;
    // var thumb = e.detail.value.thumb;
    var thumb = that.data.imgUrl;
    var imgType = that.data.imgType;
    if (imgType != 'jpg' && imgType != 'png' && imgType != 'gif' && imgType != 'bmp') {
      wx.showToast({
        title: '您上传的图片格式不正确，请重新选择！',
      })
    } else {
      wx.uploadFile({
        url: app.globalData.url + '/wxapi/User/identity/wxtoken/' + wx.getStorageSync('wxtoken') + '/type/2',
        filePath: thumb,
        name: 'image',
        success(res) {
          // wx.navigateTo({
          //   url: '../userinfo/userinfo',
          // })
          wx.showToast({
            title: '修改成功',
          })
        }
      })
    }
  },

})