var server = require('../../../utils/server');
var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    address_list: [],
    id: 0,
    goType: 0,

    action: '',
    goods_id: '',
    goods_num: '',
    item_id: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var goType = options.goType;
    // 普通订单地址选择--立即购买
    var action = options.action;
    var goods_id = options.goods_id;
    var goods_num = options.goods_num;
    var item_id = options.item_id;
    // 拼团订单地址选择参数
    var id = options.id;
    var is_crate = options.is_crate;
    var group_id = options.group_id;
    console.log(id);
    this.setData({
      goType: goType,
      id: id,
      is_crate: is_crate,
      group_id: group_id,
      action: action,
      goods_id: goods_id,
      goods_num: goods_num,
      item_id: item_id
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getAddress();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */

  //下拉刷新
  onPullDownRefresh: function () {
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function () {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1000);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function () {

  // },
  getAddress: function () {
    var that = this;
    server.getJSON('/User/address_list/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      var address_list = res.data.list;
      // console.log(res);
      that.setData({
        address_list: address_list
      });
    });
  },
  setAddress: function () {
    // wx.navigateTo({
    //   url: '../../set/edit_address/edit_address?objectId=' + this.data.id + '&goType=' + this.data.goType,
    // })
    wx.redirectTo({
      url: '../../set/edit_address/edit_address?objectId=' + this.data.id + '&goType=' + this.data.goType,
    })
  },
  updateAddress: function (e) {
    var addressId = e.currentTarget.dataset.addressId;
    // wx.navigateTo({
    //   url: '../../set/edit_address/edit_address?objectId=' + addressId + '&goType=' + this.data.goType,
    // })
    wx.redirectTo({
      url: '../../set/edit_address/edit_address?objectId=' + addressId + '&goType=' + this.data.goType,
    })
  },
  backQueren: function (e) {
    var that = this;
    var goType = that.data.goType;
    var addressId = e.currentTarget.dataset.addressId;
    var is_default = e.currentTarget.dataset.defaultId;
    var action = that.data.action;
    var goods_id = that.data.goods_id;
    var goods_num = that.data.goods_num;
    var item_id = that.data.item_id;
    if (goType == 1) {
      if (is_default == 1) {
        // wx.navigateTo({
        //   url: '../../other/queren/queren?action=' + action + '&goods_id=' + goods_id + '&goods_num=' + goods_num + '&item_id=' + item_id,
        // })
        wx.redirectTo({
          url: '../../other/queren/queren?action=' + action + '&goods_id=' + goods_id + '&goods_num=' + goods_num + '&item_id=' + item_id,
        })
      } else {
        server.getJSON('/User/set_default/wxtoken/' + wx.getStorageSync('wxtoken') + '/id/' + addressId, function (res) {
          // wx.navigateTo({
          //   url: '../../other/queren/queren?action=' + action + '&goods_id=' + goods_id + '&goods_num=' + goods_num + '&item_id=' + item_id,
          // })
          wx.redirectTo({
            url: '../../other/queren/queren?action=' + action + '&goods_id=' + goods_id + '&goods_num=' + goods_num + '&item_id=' + item_id,
          })
        })
      }
    } else if (goType == 2) {
      if (is_default == 1) {
        // wx.navigateTo({
        //   url: '../../collage/queren/queren?id=' + that.data.id + '&is_crate=' + that.data.is_crate + '&group_id=' + that.data.group_id,
        // })
        wx.redirectTo({
          url: '../../collage/queren/queren?id=' + that.data.id + '&is_crate=' + that.data.is_crate + '&group_id=' + that.data.group_id,
        })
      } else {
        server.getJSON('/User/set_default/wxtoken/' + wx.getStorageSync('wxtoken') + '/id/' + addressId, function (res) {
          // wx.navigateTo({
          //   url: '../../collage/queren/queren?id=' + that.data.id + '&is_crate=' + that.data.is_crate + '&group_id=' + that.data.group_id,
          // })
          wx.redirectTo({
            url: '../../collage/queren/queren?id=' + that.data.id + '&is_crate=' + that.data.is_crate + '&group_id=' + that.data.group_id,
          })
        })
      }
    }
  },
  // 删除地址
  delAddress: function (e) {
    var that = this;
    var id = e.currentTarget.dataset.addressId;
    wx.showModal({
      title: '提示',
      content: '是否删除',
      success: function (res) {
        if (res.confirm) {
          // console.log('confirm确定');
          server.getJSON('/User/del_address/wxtoken/' + wx.getStorageSync('wxtoken') + '/id/' + id, function (res) {
            if (res.data.status == 1) {
              that.getAddress();
            } else {
              wx.showToast({
                title: res.data.msg,
                icon: 'none',
              })
            }
          })
        }
      }
    })
  },
})