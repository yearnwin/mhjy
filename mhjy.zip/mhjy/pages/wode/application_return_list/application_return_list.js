// pages/wode/application_return_list/application_return_list.js
var server = require('../../../utils/server');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goods_list:'',
    p:1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  //退换货
  onLoad: function (options) {
    this.getOrders();
  },

  getOrders: function () {
    var that = this;
    server.getJSON('/Order/return_goods_list/type/1/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      console.log(res);
      var goods_list = res.data.list;
      var gg = res.data.list.goods_list;
      that.setData({
        goods_list: goods_list
      });
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  
  //下拉刷新
  onPullDownRefresh:function()
  {
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
    that.getOrders();
  },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var that = this
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function () {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1000);
    var p = that.data.p + 1
    server.getJSON('/Order/return_goods_list/wxtoken/' + wx.getStorageSync('wxtoken') + '/p/' + p, function (res) {
      // console.log(res);
      var goods_list = res.data.list;
      var gg = res.data.list.goods_list;
      that.setData({
        goods_list: goods_list
      });
    });
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})