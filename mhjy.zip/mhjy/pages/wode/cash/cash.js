var server = require('../../../utils/server');
var app = getApp();
var sliderWidth = 96; // 需要设置slider的宽度，用于计算中间位置
Page({
  data: {
    tabs: ["全部", "赚取", "消费"],
    activeIndex: 0,
    sliderOffset: 0,
    sliderLeft: 0,
    account_list: [],
    money: 0,
    type: 'all',
    p: 1
  },
  onLoad: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          sliderLeft: (res.windowWidth / that.data.tabs.length - sliderWidth) / 2,
          sliderOffset: res.windowWidth / that.data.tabs.length * that.data.activeIndex
        });
      }
    });
    that.getAccountList();
  },
  tabClick: function (e) {
    var typeId = e.currentTarget.id;
    this.setData({
      sliderOffset: e.currentTarget.offsetLeft,
      activeIndex: typeId
    });
    if (typeId == 0) {
      this.setData({
        type: 'all',
        p: 1
      })
      // this.getAccountList('all');
    } else if (typeId == 1) {
      this.setData({
        type: 'plus',
        p: 1
      })
      // this.getAccountList('plus');
    } else if (typeId == 2) {
      this.setData({
        type: 'minus',
        p: 1
      })
      // this.getAccountList('minus');
    }
    this.getAccountList();
  },
  getAccountList: function () {
    var that = this
    var atype = that.data.type;
    server.getJSON('/User/cash_list/wxtoken/' + wx.getStorageSync('wxtoken') + '/type/' + atype, function (res) {
      if (res.data.status == 1) {
        var money = res.data.result.money;
        var account_list = res.data.result.list;
        that.setData({
          money: money,
          account_list: account_list,
        });
      } else if (res.data.status == -1) {
        wx.navigateTo({
          url: '../choice/choice',
        })
      }
      
    });
  },
  
  //下拉刷新
  onPullDownRefresh:function()
  {
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
    this.setData({
      p: 1
    })
    this.getAccountList();
  },

  //上拉刷新
  onReachBottom: function () {
    var that = this
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function () {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1000);
    var p = that.data.p + 1;
    that.setData({
      p: p
    })
    // server.getJSON('/User/cash_list/wxtoken/' + wx.getStorageSync('wxtoken') + '/type/' + atype, function (res) {
    server.getJSON('/User/cash_list/type/' + that.data.type + '/wxtoken/' + wx.getStorageSync('wxtoken') + '/p/' + that.data.p, function (res) {
      var len = res.data.result.list.length;
      if (len > 0) {
        that.setData({
          coupon_list: that.data.coupon_list.concat(res.data.result.list),
        });
      }
    })
  },


  
});