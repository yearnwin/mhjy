// pages/wode/myapple/myapple.js
var server = require('../../../utils/server');
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        goods_list:[],
        url: app.globalData.url,
        status:0
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        this.statusOrderList()
    },
    statusOrderList: function () {
        var that = this
        var uid = app.globalData.unionId;
        server.getJSON('/User/myAppleList/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
            var goods_list = res.data.list;
            console.log(res.data.list)
            // var gg = res.data.list.goods_list;
            // console.log(gg)
            that.setData({
                goods_list: goods_list
            });

        });

    },


    goessaydet:function(e){
        var goodsId = e.currentTarget.dataset.myid;
        wx.navigateTo({
            url: "../myappledet/myappledet?order_id=" + goodsId
        });
    },


    gopage:function(e){
       var that=this;
        var oid = e.currentTarget.dataset.oid;
        var way = e.currentTarget.dataset.way;
      server.getJSON('/user/order/order_id/' + oid + '/way/' + way + '/wxtoken/' + wx.getStorageSync('wxtoken'),function(res){
            console.log(res);
          if(res.data.status==1){
            that.setData({
              status: 1
            })
            wx.showToast({
              title: res.data.msg,
            })
                // wx.switchTab({
                //   url: '../../mine/mine?oid=' + oid + '&way=' + way
                // })
           

          }else{
                wx.showToast({
                  title: res.data.msg,
                })
          }

        

        })

        
    },



    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
   
})