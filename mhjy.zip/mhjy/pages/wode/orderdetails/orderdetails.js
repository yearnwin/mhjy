// pages/wode/orderdetails/orderdetails.js
var app = getApp();
var server = require('../../../utils/server');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    orderdetails:'',
    orderid:0,
    // order_status: 0,
    // order_status_desc: ''
    shop_info_mobile:'',
    money: 0,
    goods:[],
    user_id: '',
    goods_img_nk:[],
    goods_images_nk:'',
    goods_id: '',
    share_img: '',
    goods_name: ''
  },
  //联系电话
  cal:function(){
    // 卖家联系电话
    server.getJSON('/MobileBase/public_assign', function (res) {
      console.log(res);
      wx.makePhoneCall({
        phoneNumber: res.data.result.shop_info_mobile //仅为示例，并非真实的电话号码
      })
      this.setData({
        shop_info_mobile: res.data.result.shop_info_mobile
      });
    });
  },

  share:function(){

  },


  //联系我们客服
  calme:function(){
      wx.navigateTo({
        url:'../../other/kefu/kefu'
      })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
        var orderId=options.order_id;
        this.setData({
          orderid: orderId
        })

        this.orderdatails(orderId);
        this.userInfo();

  },
  // 订单详情
  orderdatails: function (id) {
    var that = this
    var uid = app.globalData.unionId;
    //详情请求                               
    server.getJSON('/Order/order_detail/id/' + id + '/wxtoken/' + wx.getStorageSync('wxtoken'), function (res)
    {
      console.log(res);
      var orderdetails = res.data.list;
      console.log(res.data.money);
      that.setData({
        orderdetails: orderdetails,
        money: res.data.money,
        goods: orderdetails.goods_list,
        goods_name: orderdetails.goods_list[0].goods_name,
        goods_id: orderdetails.goods_list[0].goods_id,
        share_img: orderdetails.goods_list[0].share_img
        // order_status_desc: orderdetails.order_status_desc,
        // order_status: orderdetails.order_status,
      });
    });
  },

  
  // 再来一单
  agentOrder:function(e){
      var that=this
      var order_id = e.currentTarget.dataset.orderId;
      console.log('咋哩来');
      console.log(order_id);  
      wx.switchTab({
        url: "../../cart/cart?objectid=" + order_id
      })
  },

  // 确认收货
  makeSure: function () {
    var that = this;
    var order_id = that.data.orderid;
    server.getJSON('/Order/order_confirm/wxtoken/' + wx.getStorageSync('wxtoken') + '/id/' + order_id, function (res) {
      if (res.data.status == 1) {
        that.orderdatails(order_id);
      } else {
        wx.showToast({
          title: res.data.msg,
        })
      }
    })
  },

  // 评价
  goComment: function (e) {
    var recId = e.currentTarget.dataset.recId;
    wx.navigateTo({
      url: '../pingjia/pingjia?recId=' + recId,
    })
  },
  // 查看物流
  express: function (ex) {
    console.log(ex);
      var rec_id = ex.currentTarget.dataset.recId
      wx.navigateTo({
        url: '../../other/express/express?id=' + rec_id,
      })
  },

 
  //商品详情
  goodsDet:function(e){
    var goodsId=e.currentTarget.dataset.goodsId;
    wx.navigateTo({
      url: "../../goods/details/details?objectId=" + goodsId
    })
  },

  // 立即购买
  buyNow:function(e){
   
   console.log(e);
    // order_id = 897 & amount=132.00
    var orderid=e.currentTarget.dataset.orderId
    console.log(this);
     var amount=this.data.orderdetails.order_amount
    console.log(amount);
    wx.navigateTo({
      url: '../../other/pay/pay?order_id='+orderid+'&amount='+amount,
    })

  },

  userInfo: function () {
    var that = this;
    var wxtoken = wx.getStorageSync('wxtoken');
    server.getJSON('/Cart/users/wxtoken/' + wxtoken, function (res) {
      if (res.data.status == 1) {
        that.setData({
          user_id: res.data.user.user_id
        })
      }
    })
  }, 

  // 点击分享时获得
  getGoodsId: function (e) {
    var goodsId = e.currentTarget.dataset.goodsId;
    var shareImg = e.currentTarget.dataset.shareImg;
    var goodsName = e.currentTarget.dataset.goodsName;
    console.log(shareImg);
    this.setData({
      goods_id: goodsId,
      share_img: shareImg,
      goods_name: goodsName
    })
  },

  //分享
  onShareAppMessage:function() {
    // var that = this
    // var scene = 1;
    // var goods_id = that.data.goods_id;
    // var goods_name = that.data.goods_name;
    // var img = that.data.share_img;
    // var user_id = that.data.user_id;
    // console.log(img);
    // console.log(goods_name);
    // console.log(goods_id);
    // console.log(user_id);
    // return {
    //   title: goods_name,
    //   desc: '物华兴邦',
    //   imageUrl: img,
    //   path: '/pages/goods/details/details?objectId=' + goods_id + '&scene=' + scene + '&first_leader=' + user_id
    // }
  },

 

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
 
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

})