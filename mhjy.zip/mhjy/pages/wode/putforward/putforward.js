var server = require('../../../utils/server');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    verify: '',
    bank_card: '',
    bank_name: '',
    money: '',
    realname: '',
    paypwd: '',
    verimg: '../../../img/ceshi.jpg',
    url: app.globalData.url,
    point:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.change();
    
  },
  // 提现积分比例
  point: function (money){
    var that=this
    server.getJSON('/User/point/wxtoken/' + wx.getStorageSync('wxtoken')+'/money/'+money,function(res){
          if(res.data.msg=='a'){
            that.setData({
              point: res.data.value,
              money: res.data.money
            })
          }else{
            wx.showToast({
              title: res.data.msg,
            })
          }
            
      })
  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
 
//下拉刷新
  onPullDownRefresh:function()
  {
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
  },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  money: function (e) {
    var money = e.detail.value;
    this.point(money);
   
  },
  bankName: function (e) {
    this.setData({
      bank_name: e.detail.value,
    })
  },
  bankCard: function (e) {
    this.setData({
      bank_card: e.detail.value,
    })
  },
  realName: function (e) {
    this.setData({
      realname: e.detail.value,
    })
  },
  verify: function (e) {
    this.setData({
      verify: e.detail.value,
    })
  },
  change: function () {
    this.setData({
      verimg: app.globalData.url + '/wxapi/User/verify/type/withdrawals/wxtoken/' + wx.getStorageSync('wxtoken') + '/r=' + Math.random(),
    })
  },





  submit: function () {
    var that = this;
    var money = that.data.money;
    var bank_name = that.data.bank_name;
    var bank_card = that.data.bank_card;
    var realname = that.data.realname;
    var verify = that.data.verify;
    if (money == '' || bank_name == '' || bank_card == '' || realname == '') {
      wx.showToast({
        title: '所有选项为必填！',
      })
    }else if (verify == '') {
      wx.showToast({
        title: '请输入验证码！',
      })
    }else {
      console.log(verify);
      // server.getJSON('/User/withdrawals/unionid/' + app.globalData.unionId + '/money/' + money + '/bank_name/' + bank_name + '/bank_card/' + bank_card + '/realname/' + realname + '/verify_code/' + verify, function (res) {
      //   // console.log(res.data)
      //   wx.showToast({
      //     title: res.data.msg,
      //   })
      // });
      console.log(wx.getStorageSync('wxtoken'))
      wx.request({
        url: app.globalData.url + '/wxapi/User/withdrawals',
        data: {
          wxtoken: wx.getStorageSync('wxtoken'),
          money: money,
          bank_name: bank_name,
          bank_card: bank_card,
          realname: realname,
          verify_code: verify
        },
        method: 'POST',
        success(res){
          console.log(res);
          wx.showToast({
            title: res.data.msg
          })
        }
      })
    }
  }
})