// pages/wode/qiye/qiye.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  startLogin: function (e) {
    // console.log(e.detail.value)
    var that = this;
    var username = e.detail.value.email;
    var password = e.detail.value.password;
    if (username == '') {
      wx.showToast({
        title: '请输入邮箱',
        icon: 'none',
      });
      return false;
    }
   
    if (password == '') {
      wx.showToast({
        title: '密码不能为空',
        icon: 'none',

      });
      return false;
    }
    wx.request({
      url: app.globalData.url + '/wxapi/LoginApi/app_login',
      data: { username: username, password: password },
      success: res => {
        //成功的话直接跳转到个人中心       
        var oStatus = res.data.status;
        console.log(res)
        var info = res.data.info;
        if (oStatus == 1) {
          // var session_id = res.data.session_id;         
          wx.setStorageSync('wxtoken', res.data.result.wxtoken);   
          wx.setStorageSync('app_send_user_id', '');
          wx.showToast({
            title: '登录成功',
            duration: 2000,
          }) 
          wx.navigateBack({
            delta: 2
          })         
          // wx.switchTab({
          //   url: '../../mine/mine?username=' + username
          // })
          
        } 
        if (oStatus == -1) {
          wx.showToast({
            title: '账号不存在',
            duration: 2000,
            icon:'none',
          })
        }
        if (oStatus == -2) {
          wx.showToast({
            title: '密码错误',
            duration: 2000,
            icon: 'none',
          })
        }
      }
    }) 
    },


})