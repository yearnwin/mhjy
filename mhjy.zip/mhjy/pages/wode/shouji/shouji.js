// pages/wode/shouji/shouji.js
var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    username: '',
    password: '',
    loginErrorCount: 0,
    isLogin: '',
    dataList: '',
    boolean: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
   startLogin: function (e) {
     console.log(e.detail.value)
    var that = this;
     var username = e.detail.value.username;
    var password= e.detail.value.password;
     if (username == '') {
       wx.showToast({
         title: '请输入手机号',
         icon: 'none',
       });
       return false;
     }
    
     if (password == '') {
       wx.showToast({
         title: '密码不能为空',
         icon: 'none',

       });
       return false;
     }
     wx.request({
       url: app.globalData.url + '/wxapi/LoginApi/app_login',
       data: { username: username, password: password},
       success: res => {
         //成功的话直接跳转到个人中心       
         var oStatus = res.data.status;
         console.log(res)
         var info = res.data.info;
         if (oStatus == 1) {
           // var session_id = res.data.session_id;         
           wx.setStorageSync('wxtoken', res.data.result.wxtoken); 
           wx.setStorageSync('app_send_user_id', '');
          //  wx.showToast({
          //    title: '登录成功',
          //    duration: 2000,
          //  }) 
          //  wx.navigateBack({
          //    delta: 2
          //  })          
          //  wx.switchTab({
          //    url: '../../mine/mine?username=' + username
          //  })
           wx.showToast({
             title: '登录成功',
             duration: 3000,
             success: function () {
               setTimeout(function () {
                 wx.switchTab({
                   url: '../../mine/mine',
                 })
               }, 2000) //延迟时间
             }
           })


         } 
         if (oStatus == -2)  {
           // console.log(1)         
           // info: res.data.info
           wx.showToast({
             title: '密码错误',
             duration: 2000,
             icon:'none',
           })
           
         }
         if (oStatus == -1) {
           // console.log(1)         
           // info: res.data.info
           wx.showToast({
             title: '手机号不存在',
             duration: 2000,
             icon: 'none',
           })
           
         }
       }
     })      

    // if (that.data.password.length < 1 || that.data.username.length < 1) {
    //   wx.showModal({
    //     title: '错误信息',
    //     content: '请输入用户名和密码',
    //     showCancel: false
    //   });
    //   return false;
    // }
wx.login({      
  success: res => {       
  console.log(res)        
  // 发送 res.code 到后台换取 openId, sessionKey, unionId        
  //获取encryptedData和iv        
  let encryptedData = wx.getStorageSync('encryptedData');       
  let iv = wx.getStorageSync('iv');      
   let code = res.code;        
   //获取用户信息        
   wx.getUserInfo({          
   success: function (res) {           
   let encryptedData = res.encryptedData;            
   let iv = res.iv;            
   that.setData({              
   encryptedData: encryptedData,             
   iv: iv           
    });           
    //发送请求            
    wx.request({              
    url: 'https://mhjy.zqcom.cc/wxapi/LoginApi/login',
    data: { code: code, encryptedData: encryptedData, iv: iv },             
    success: res => {               
    console.log(res)                
    let oStatus = res.data.status;                
    console.log(oStatus)                
    if (oStatus == 100) {                 
    let isLogin1 = res.data.is_first_login;                 
    if (isLogin1 == 1) {                    
    //跳转到注册页面                   
    wx.redirectTo({                     
    url: '../register/index?code=' + code,                    
    })                  
    } else if (isLogin1 == 2) {                   
    //let avatarUrl = wx.getStorageSync('avatarUrl');                   
    wx.request({                      
    url: 'https://www.muwai.com/index.php/Xcx/Login/wx_login',                      
    data: { code: code, username: '', phone: '', password: '', phone_code: '', head_photo: '' },                      
    success: res => {                       
    //成功的话直接跳转到首页                       
    let oStatus = res.data.status;                        
    if (oStatus == 100) {                         
    let session_id = res.data.session_id;                         
    wx.setStorageSync('session_id', session_id);                          
    wx.switchTab({                           
     url: '../index/index?session_id=' + session_id                          
     })                          
     that.setData({                            
     boolean: true                         
     });                       
     }                       
     }                   
     })                  
     }               
     } else {                  
     //记得以后给用户告知错误信息                 
     that.setData({                    
     info: res.data.info                 
     });                 
     //console.log(res.data.info)                
   }             
  }           
  })         
   }       
  })      
  }   
})  

  
  },
  bindUsernameInput: function (e) {

    this.setData({
      username: e.detail.value
    });
  },
  bindPasswordInput: function (e) {

    this.setData({
      password: e.detail.value
    });
  },
  clearInput: function (e) {
    switch (e.currentTarget.id) {
      case 'clear-username':
        this.setData({
          username: ''
        });
        break;
      case 'clear-password':
        this.setData({
          password: ''
        });
        break;
     
        break;
    }
  },
  forget:function(){
    wx.navigateTo({
      url: '../../set/retrieve/retrieve',
    })
  },
 
})